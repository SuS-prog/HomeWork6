public class PriorityQueue {
    int SIZE = 5;
    int[] items = new int[SIZE];
    int front, rear;
     PriorityQueue(){
        front = -1;
        rear = -1;
    }
    public static void quickSort(int[] source, int leftBorder, int rightBorder){
        int leftMarker = leftBorder;
        int rightMarker = rightBorder;
        int pivot = source[(leftMarker + rightMarker) / 2];
        do{
            while(source[leftMarker] < pivot){
                leftMarker++;
            }
            while(source[rightMarker] > pivot){
                rightMarker--;
            }
            if(leftMarker <= rightMarker){
                if(leftMarker < rightMarker){
                    int tmp = source[leftMarker];
                    source[leftMarker] = source[rightMarker];
                    source[rightMarker] = tmp;
                }
                leftMarker++;
                rightMarker--;
            }
        } while(leftMarker <= rightMarker);

        if(leftMarker < rightBorder){
            quickSort(source,leftMarker, rightBorder);
        }
        if(leftMarker < rightMarker){
            quickSort(source, leftMarker, rightMarker);
        }
    }
    boolean isFull(){
        if(rear == SIZE -1 && front == 0){
            return true;
        }
        return false;
    }
    boolean isEmpty(){
        if(front == -1)
            return true;
        else
            return false;
    }
    void addQueue(int element){
        if(isFull()){
            System.out.println("Очередь заполнена!");
        }else {
            if(front == -1){
                front = 0;
            }
            rear++;
            items[rear] = element;
            quickSort(items, front, rear);
            System.out.println("Добавлен элемент " + element);
        }
    }
    int delQueue(){
        int element;
        if (isEmpty()){
            System.out.println("Очередь пустая");
            return (-1);
        }else{
            element = items[front];
            if (front >= rear){
                front = -1;
                rear = -1;
            }else{
                front++;
            }
            System.out.println("Удален элемент -> " + element);
            return element;
        }
    }
    void display(){
        int i;
        if (isEmpty()){
            System.out.println("Пустая очередь");
        }else {
            System.out.println("\nИндекс FRONT: " + front);
            System.out.println("Индекс REAR: " + rear);
            System.out.println("\nЭлементы: ");
            for (i = front; i <= rear ; i++) {
                System.out.println(items[i] + " ");
            }
        }
    }
}
