public class Stack {
    private int capacity;
    private int[] items;
    int top;

    public Stack(int size){
        items = new int[size];
        capacity = size;
        top = -1;
    }
    private boolean isFull(){
        return top == capacity -1;
    }

    private boolean isEmpty(){
        return top == -1;
    }

    public void push(int x){
        if(isFull()){
            System.out.println("Стек заполнен");
            System.exit(1);
        }
        items[++top] = x;
        System.out.println("Добавлен элемент " + x);
    }

    public int pop(){
        if(isEmpty()){
            System.out.println("Стек пустой");
            System.exit(1);
        }
        return items[top--];
    }

    public int size(){
        return top + 1;
    }

    void display(){
        int i;
        if (isEmpty()){
            System.out.println("Стек пустой");
        }else {
            System.out.println("\nИндекс TOP: " + top);
            System.out.println("\nЭлементы: ");
            for (i = top; i >= 0 ; i--) {
                System.out.println(items[i]);
            }
            System.out.println();
        }
    }
}
