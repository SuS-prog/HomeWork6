
public class Main {
    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue();
        pq.delQueue();

        pq.addQueue(2);
        pq.addQueue(4);
        pq.addQueue(1);
        pq.addQueue(3);
        pq.addQueue(5);

        pq.addQueue(6);

        pq.delQueue();
        
        pq.display();
    }
}
